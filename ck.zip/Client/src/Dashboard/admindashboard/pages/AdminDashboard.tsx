
const AdminDashboard = () => {
  return (
    <div>AdminDashboard page is added soon...</div>
  )
}

export default AdminDashboard