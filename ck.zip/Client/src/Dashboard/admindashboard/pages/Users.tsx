const Users = () => {
  return (
    <div>Users page is added soon...</div>
  )
}

export default Users